//Draw.java
package App.Abstracts;

public interface Draw {
    void drawShape();
}
