package p1;

public class SamePackage {
    
}
