package p1;

public class Derived extends Protection {
    
}
