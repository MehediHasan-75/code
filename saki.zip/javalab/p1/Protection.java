package p1;

public class Protection {
    public int pub=1;
    int def=10;
    // protected int pro=100;
    // private int pri=100;

}
