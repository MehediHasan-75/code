package mypackage;

public class two {
    
}
