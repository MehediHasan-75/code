package p2;

public class Protection2 {
    
}
